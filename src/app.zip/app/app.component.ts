import { Component } from '@angular/core';

@Component({
  selector: 'cenfo-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'cenfo-angular';
}
