import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cenfo-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
